import sys
import os
import hashlib
import sqlite3
from urllib.parse import urlparse

from PyQt5.QtWidgets import QApplication
import requests

import db_manager
import scraper
import main_window
from main_window import MainWindow


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(BASE_DIR, "assets", "cache_images")


def _normalize_event_row(row):
    """Menyamakan format data event dari DB menjadi dictionary untuk UI."""
    # db_manager.get_all_events() saat ini mengembalikan tuple SELECT *:
    # (id, event_id, nama_event, deskripsi_singkat, gambar_poster,
    #  jenis_event, tanggal_waktu, source, kategori)
    if isinstance(row, dict):
        return {
            "event_id": row.get("event_id", ""),
            "jenis_event": (row.get("jenis_event", "External") or "External").title(),
            "nama_event": row.get("nama_event", "Tanpa Judul") or "Tanpa Judul",
            "deskripsi_singkat": row.get("deskripsi_singkat", "") or "",
            "tanggal_waktu": row.get("tanggal_waktu", "TBA") or "TBA",
            "gambar_poster": row.get("gambar_poster", "") or "",
        }

    return {
        "event_id": row[1] if len(row) > 1 else "",
        "jenis_event": (row[5] if len(row) > 5 and row[5] else "External").title(),
        "nama_event": row[2] if len(row) > 2 and row[2] else "Tanpa Judul",
        "deskripsi_singkat": row[3] if len(row) > 3 and row[3] else "",
        "tanggal_waktu": row[6] if len(row) > 6 and row[6] else "TBA",
        "gambar_poster": row[4] if len(row) > 4 and row[4] else "",
    }


def _is_http_url(value):
    """Mengecek apakah nilai adalah URL gambar online (http/https)."""
    return isinstance(value, str) and value.startswith(("http://", "https://"))


def _cache_image(image_url):
    """Menyimpan gambar URL ke cache lokal agar loading UI lebih cepat/stabil."""
    # Jika bukan URL online, langsung pakai path asli.
    if not _is_http_url(image_url):
        return image_url

    # Pastikan folder cache tersedia.
    os.makedirs(CACHE_DIR, exist_ok=True)

    parsed = urlparse(image_url)
    ext = os.path.splitext(parsed.path)[1].lower()
    if ext not in {".jpg", ".jpeg", ".png", ".webp"}:
        ext = ".jpg"

    # Nama file cache dibuat deterministik dari URL (MD5).
    file_name = hashlib.md5(image_url.encode("utf-8")).hexdigest() + ext
    local_path = os.path.join(CACHE_DIR, file_name)

    # Jika sudah pernah diunduh, pakai file lokal.
    if os.path.exists(local_path):
        return local_path

    try:
        # Download gambar sekali, lalu simpan untuk pemakaian berikutnya.
        response = requests.get(
            image_url,
            timeout=10,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                )
            },
        )
        response.raise_for_status()
        with open(local_path, "wb") as f:
            f.write(response.content)
        return local_path
    except requests.RequestException:
        # Fallback: kembalikan URL asli jika unduh gagal.
        return image_url


def _load_ui_events_from_db():
    """Mengambil event dari DB, normalisasi field, lalu siapkan path gambar untuk UI."""
    rows = db_manager.get_all_events()
    events = []

    for row in rows:
        event = _normalize_event_row(row)
        
        # Pastikan field wajib tidak pernah kosong agar card render konsisten
        if not event.get("deskripsi_singkat") or event.get("deskripsi_singkat").strip() == "":
            event["deskripsi_singkat"] = "..."
        
        if not event.get("tanggal_waktu") or event.get("tanggal_waktu").strip() == "":
            event["tanggal_waktu"] = "TBA"
        
        if not event.get("jenis_event") or event.get("jenis_event").strip() == "":
            event["jenis_event"] = "External"
        
        event["gambar_poster"] = _cache_image(event.get("gambar_poster", ""))
        events.append(event)

    # Dipakai untuk mengganti dummy data saat data DB tersedia.
    return events


def _event_identity(event):
    """Identitas sederhana untuk mendeteksi event yang sudah pernah tersimpan."""
    nama_event = (event.get("nama_event") or "").strip().lower()
    tanggal_waktu = (event.get("tanggal_waktu") or "").strip().lower()
    return nama_event, tanggal_waktu


def _sync_scraped_events_to_db():
    """Ambil data dari scraper, lalu tambahkan event baru saja tanpa mengulang data lama."""
    conn = sqlite3.connect(db_manager.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT nama_event, tanggal_waktu FROM events")
    existing_keys = {
        ((row[0] or "").strip().lower(), (row[1] or "").strip().lower())
        for row in cursor.fetchall()
    }

    hasil_scraping = scraper.ambil_event_polban(limit=100, existing_keys=existing_keys)
    if not hasil_scraping:
        conn.close()
        return False

    inserted_count = 0

    for event in hasil_scraping:
        event_key = _event_identity(event)

        # Begitu ketemu event yang sudah ada, asumsi sisanya adalah data lama.
        # Ini cocok untuk website yang urut dari event terbaru ke yang lebih lama.
        if event_key in existing_keys:
            print(f"Data lama ditemukan di scraper: {event.get('nama_event')} - hentikan scraping lanjutan.")
            break

        cursor.execute("""
        INSERT OR IGNORE INTO events
        (event_id, nama_event, deskripsi_singkat, gambar_poster,
         jenis_event, tanggal_waktu, source, kategori, lokasi, nama_eo, tipe_tiket, harga_tiket)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event.get("event_id"),
            event.get("nama_event"),
            event.get("deskripsi_singkat"),
            event.get("gambar_poster"),
            event.get("jenis_event"),
            event.get("tanggal_waktu"),
            event.get("source"),
            event.get("kategori"),
            event.get("lokasi", "Jawa Barat"),      # ← TAMBAH
            event.get("penyelenggara", "Polban"),             # ← TAMBAH
            event.get("tipe_tiket", "Free"),                 # ← TAMBAH
            event.get("harga_tiket", "0"),  
        ))
        inserted_count += 1
        existing_keys.add(event_key)

    conn.commit()
    conn.close()
    return inserted_count > 0


def main():
    """Entry point aplikasi: init DB, siapkan data UI, lalu jalankan PyQt app."""
    # Ensure local database and table exist before UI is shown.
    db_manager.init_db()

     # Jalankan scraping saat aplikasi dimulai agar data yang tampil selalu diperbarui.
    _sync_scraped_events_to_db()
    
    # Muat data event dari DB untuk ditampilkan di homepage.
    db_events = _load_ui_events_from_db()
    if db_events:
        # Override dummy list in main_window only when DB has data.
        main_window.dummy_events = db_events

    # Inisialisasi aplikasi Qt dan tampilkan jendela utama.
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    window = MainWindow()
    if db_events:
        window.refresh_tampilan_homepage()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()